//1. Get Call Method
function makeGetRequest() {
    const id=7;
    const apiURL ='https://api.restful-api.dev/objects';
    axios.get(apiURL).then(
        (response) => {
            var result = response.data;
            console.log("Get Call Method :"+JSON.stringify(result));
            document.getElementById('response-data').innerHTML = JSON.stringify(result);
        },
        (error) => {
            console.log(error);
        }
    );
}
//makeGetRequest();

//2. List of objects by ids
function listOfObjectByIds() {
    var params = new URLSearchParams();
    params.append("id", 3);
    params.append("id", 5);
    params.append("id", 10);
    
    const requestParams = {
        params: params
    };      
    const apiURL ='https://api.restful-api.dev/objects';
    axios.get(apiURL, requestParams).then(
        (response) => {
            var result = response.data;
            console.log("List of objects by ids :"+JSON.stringify(result));
            document.getElementById('response-data').innerHTML = JSON.stringify(result);
        },
        (error) => {
            console.log(error);
        }
    );
}
//listOfObjectByIds();

//3. Single object
function singleObject() {
    const id=7;
    const apiURL =`https://api.restful-api.dev/objects/${id}`;
    axios.get(apiURL).then(
        (response) => {
            var result = response.data;
            console.log("Single object :"+JSON.stringify(result));
            document.getElementById('response-data').innerHTML = JSON.stringify(result);
        },
        (error) => {
            console.log(error);
        }
    );
}
//singleObject();


//4. add Single object POST
function singleObjectPost() {
    const apiURL ='https://api.restful-api.dev/objects';
    const requestData = {
       name: "Apple MacBook Pro 16",
      data: {
            "year": 2019,
            "price": 1849.99,
            "CPU model": "Intel Core i9",
            "Hard disk size": "1 TB"
     }
    };

    axios.post(apiURL,requestData).then(
        (response) => {
            var result = response.data;
            console.log("add Single object POST:"+JSON.stringify(result));
            document.getElementById('response-data').innerHTML = JSON.stringify(result);
        },
        (error) => {
            console.log(error);
        }
    );
}
//singleObjectPost();


//5. update Single object PUT/
function updateSingleObjectPost() {
    const id='ff808181932badb6019468b09e0d2c3d';
    const apiURL =`https://api.restful-api.dev/objects/${id}`;
    const requestData = {
      name: "Apple MacBook Pro 16",
      data: {
        "year": 2019,
        "price": 2049.99,
        "CPU model": "Intel Core i9",
        "Hard disk size": "1 TB",
        "color": "silver"
     }
    };

    axios.put(apiURL, requestData).then(
        (response) => {
            var result = response.data;
            console.log("update Single object PUT:" + JSON.stringify(result));
            document.getElementById('response-data').innerHTML = JSON.stringify(result);
        },
        (error) => {
            console.log(error);
        }
    );
}
//updateSingleObjectPost();


//6. Partially update object PATCH/
function patchSingleObjectPost() {
    const id = 'ff808181932badb6019468b09e0d2c3d';
    const apiURL =`https://api.restful-api.dev/objects/${id}`;
    const requestData = {
      "name": "Apple MacBook Pro 16 (Updated Name)"
    };

    axios.patch(apiURL, requestData).then(
        (response) => {
            var result = response.data;
            console.log("Partially update object PATCH:" + JSON.stringify(result));
            document.getElementById('response-data').innerHTML = JSON.stringify(result);
        },
        (error) => {
            console.log(error);
        }
    );
}
//patchSingleObjectPost();



//7. Single object Delete
/*
function deleteSingleObject() {
    const apiURL ='https://api.restful-api.dev/objects/ff808181932badb6019468ab61592c37';
    axios.delete(apiURL).then(
        (response) => {
            var result = response.data;
            console.log("Single object Delete :"+JSON.stringify(result));
        },
        (error) => {
            console.log(error);
        }
    );
}
deleteSingleObject();
*/



function renderData(){

    let result = JSON.parse(getJson());

   var text = ""
   text = text +'<table><thead><tr><th>ID</th> <th>Name</th></tr></thead><tbody>';
    for(let i=0; i< result.length; i++){
     product = result[i]; 
     text = text + '<tr><td>'+ product.id + '</td>' +
      '<td>'+ product.name + '</td></tr>' 
    }
    text = text+ '</tbody></table>';
    
    console.log(text)
    document.getElementById('response-data').innerHTML = text;  
}


function getJson(){
    return `[
  {
    "id": "1",
    "name": "Google Pixel 6 Pro",
    "data": {
      "color": "Cloudy White",
      "capacity": "128 GB"
    }
  },
  {
    "id": "2",
    "name": "Apple iPhone 12 Mini, 256GB, Blue",
    "data":{
      "color": "Cloudy White",
      "capacity": "128 GB"
    }
  },
  {
    "id": "3",
    "name": "Apple iPhone 12 Pro Max",
    "data": {
      "color": "Cloudy White",
      "capacity GB": 512
    }
  },
  {
    "id": "4",
    "name": "Apple iPhone 11, 64GB",
    "data": {
      "price": 389.99,
      "color": "Purple"
    }
  },
  {
    "id": "5",
    "name": "Samsung Galaxy Z Fold2",
    "data": {
      "price": 689.99,
      "color": "Brown"
    }
  },
  {
    "id": "6",
    "name": "Apple AirPods",
    "data": {
      "generation": "3rd",
      "price": 120
    }
  },
  {
    "id": "7",
    "name": "Apple MacBook Pro 16",
    "data": {
      "year": 2019,
      "price": 1849.99,
      "CPU model": "Intel Core i9",
      "Hard disk size": "1 TB"
    }
  },
  {
    "id": "8",
    "name": "Apple Watch Series 8",
    "data": {
      "Strap Colour": "Elderberry",
      "Case Size": "41mm"
    }
  },
  {
    "id": "9",
    "name": "Beats Studio3 Wireless",
    "data": {
      "Color": "Red",
      "Description": "High-performance wireless noise cancelling headphones"
    }
  },
  {
    "id": "10",
    "name": "Apple iPad Mini 5th Gen",
    "data": {
      "Capacity": "64 GB",
      "Screen size": 7.9
    }
  },
  {
    "id": "11",
    "name": "Apple iPad Mini 5th Gen",
    "data": {
      "Capacity": "254 GB",
      "Screen size": 7.9
    }
  },
  {
    "id": "12",
    "name": "Apple iPad Air",
    "data": {
      "Generation": "4th",
      "Price": "419.99",
      "Capacity": "64 GB"
    }
  },
  {
    "id": "13",
    "name": "Apple iPad Air",
    "data": {
      "Generation": "4th",
      "Price": "519.99",
      "Capacity": "256 GB"
    }
  }
]`;
}





